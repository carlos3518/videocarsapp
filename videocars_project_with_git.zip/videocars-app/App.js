import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  FlatList
} from 'react-native';
import { RadioButton } from 'react-native-paper';

export default function App() {
  const [filters, setFilters] = useState({
    make: '',
    model: '',
    minPrice: '',
    maxPrice: '',
    year: '',
    mileage: '',
    titleStatus: '',
    transmission: '',
  });
  const [listings, setListings] = useState([]);

  const handleApplyFilters = async () => {
    const query = new URLSearchParams(
      Object.fromEntries(
        Object.entries(filters).filter(([_, v]) => v !== '')
      )
    ).toString();

    try {
      const response = await fetch(`http://localhost:5000/api/listings?${query}`);
      const data = await response.json();
      setListings(data);
    } catch (err) {
      console.error('Failed to fetch listings:', err);
    }
  };

  const resetFilters = () => {
    setFilters({
      make: '',
      model: '',
      minPrice: '',
      maxPrice: '',
      year: '',
      mileage: '',
      titleStatus: '',
      transmission: '',
    });
    setListings([]);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Make"
        value={filters.make}
        onChangeText={text => setFilters({ ...filters, make: text })}
      />
      <TextInput
        style={styles.input}
        placeholder="Model"
        value={filters.model}
        onChangeText={text => setFilters({ ...filters, model: text })}
      />
      <View style={styles.row}>
        <TextInput
          style={[styles.input, styles.halfInput]}
          placeholder="Min Price"
          keyboardType="numeric"
          value={filters.minPrice}
          onChangeText={text => setFilters({ ...filters, minPrice: text })}
        />
        <TextInput
          style={[styles.input, styles.halfInput]}
          placeholder="Max Price"
          keyboardType="numeric"
          value={filters.maxPrice}
          onChangeText={text => setFilters({ ...filters, maxPrice: text })}
        />
      </View>
      <TextInput
        style={styles.input}
        placeholder="Year"
        keyboardType="numeric"
        value={filters.year}
        onChangeText={text => setFilters({ ...filters, year: text })}
      />
      <TextInput
        style={styles.input}
        placeholder="Mileage"
        keyboardType="numeric"
        value={filters.mileage}
        onChangeText={text => setFilters({ ...filters, mileage: text })}
      />
      <Text style={styles.label}>Title Status</Text>
      <RadioButton.Group
        onValueChange={value => setFilters({ ...filters, titleStatus: value })}
        value={filters.titleStatus}
      >
        <View style={styles.radioRow}>
          <RadioButton value="clean" />
          <Text>Clean Title</Text>
        </View>
        <View style={styles.radioRow}>
          <RadioButton value="salvage" />
          <Text>Salvage Title</Text>
        </View>
      </RadioButton.Group>

      <Text style={styles.label}>Transmission</Text>
      <RadioButton.Group
        onValueChange={value => setFilters({ ...filters, transmission: value })}
        value={filters.transmission}
      >
        <View style={styles.radioRow}>
          <RadioButton value="automatic" />
          <Text>Automatic</Text>
        </View>
        <View style={styles.radioRow}>
          <RadioButton value="manual" />
          <Text>Manual</Text>
        </View>
      </RadioButton.Group>

      <TouchableOpacity style={styles.button} onPress={handleApplyFilters}>
        <Text style={styles.buttonText}>Apply Filters</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={resetFilters}>
        <Text style={styles.resetText}>Reset</Text>
      </TouchableOpacity>

      {listings.length > 0 && (
        <FlatList
          data={listings}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.listingItem}>
              <Text style={styles.listingText}>{item.year} {item.make} {item.model}</Text>
              <Text style={styles.listingText}>${item.price}</Text>
              <Text style={styles.listingText}>Title: {item.titleStatus}</Text>
            </View>
          )}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfInput: {
    width: '48%',
  },
  label: {
    marginTop: 12,
    fontWeight: 'bold',
  },
  radioRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  resetText: {
    color: '#777',
    textAlign: 'center',
    marginTop: 10,
  },
  listingItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  listingText: {
    fontSize: 16,
  },
});