# VideoCars App

This is a React Native + Expo mobile app for filtering and viewing video car listings.

## Run locally:
```
npm install
npm start
```

Update API URL in `App.js` to point to your backend.
