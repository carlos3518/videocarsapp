# VideoCars API

This is a mock Express backend API for car listings.

## Run locally:
```
npm install
node server.js
```

Listens on port 5000 and supports query-based filtering.
