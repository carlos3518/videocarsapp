const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());

const listings = [
  { id: 1, make: 'Toyota', model: 'Camry', year: '2020', price: '15000', mileage: '30000', titleStatus: 'clean', transmission: 'automatic' },
  { id: 2, make: 'Honda', model: 'Civic', year: '2018', price: '12000', mileage: '40000', titleStatus: 'salvage', transmission: 'manual' },
  { id: 3, make: 'Tesla', model: 'Model 3', year: '2021', price: '35000', mileage: '15000', titleStatus: 'clean', transmission: 'automatic' },
];

app.get('/api/listings', (req, res) => {
  const filtered = listings.filter(item => {
    return Object.entries(req.query).every(([key, value]) =>
      item[key].toLowerCase().includes(value.toLowerCase())
    );
  });
  res.json(filtered);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});